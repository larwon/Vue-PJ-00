<template>
  <NavBarName />
</template>

<script>
import NavBarName from './components/NavBar.vue'

export default {
  name: 'App',
  components: {
    NavBarName,
  }
}
</script>

<style>

</style>