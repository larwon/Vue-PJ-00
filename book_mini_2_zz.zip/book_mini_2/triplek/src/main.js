import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import './index.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.esm.min.js'


createApp(App).mount('#app')
