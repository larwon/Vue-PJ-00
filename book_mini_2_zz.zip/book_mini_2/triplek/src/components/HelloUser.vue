<template>
  <div>
    <h1>컴포넌트 사용하기</h1>
    <h3>재미있는 {{ item }} 수업!</h3>
  </div>
</template>

<script>
export default {
    name: 'HelloUser',
    props: {
        item: String
    }
}
</script>

<style>

</style>